//change into interface

public interface Filter {
	
	public Boolean isRelavent(String phrase, String key);
	public String saperate(String phrase, String key);
	
	/*
	public static Boolean isRelavent(String phrase, String key){
		if (phrase.toLowerCase().contains(key))
			return true;
		else
			return false;
	}
	
	public static String saperate(String phrase, String key){
		return phrase.split("https")[0];		
	}
	*/
}
