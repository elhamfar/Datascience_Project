
public class PastNews {

}
