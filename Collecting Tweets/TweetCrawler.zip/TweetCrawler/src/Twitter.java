import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import twitter4j.Paging;
import twitter4j.Query;
import twitter4j.QueryResult;

import java.io.*;
import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;


public class Twitter<E> implements SocialMedia {

	private static String TWITTER_APP_KEY = "r1caQuJUyHriIyRiAndgczenp";
	private static String TWITTER_APP_KEY_SECRET = "HLhk951tcKdgGLwzO9XaCT9iSEACyU5xQkLtgrUHdpl243ktDo";
	private static String TWITTER_ACCESS_TOKEN = "4588319302-FJKWqoQB7riApELZ48WA5pVdURNgChvDvyJm8fA";
	private static String TWITTER_ACCESS_TOKEN_SECRET = "78SAggw6AEbzcWkDEFG0LEolZ0UsSbX2t8mnRaFCCywEk";
	private static twitter4j.Twitter twitter;
	private static PrintWriter outputFile;
	private static Boolean isConfigured = false;
	private static List<String> newsTweeps = new ArrayList<String>();
	private static Query q;

	public Twitter() throws TwitterException{
		if(!isConfigured){
			ConfigurationBuilder config = new ConfigurationBuilder();

			config.setDebugEnabled(true)
			.setOAuthConsumerKey(TWITTER_APP_KEY)
			.setOAuthConsumerSecret(TWITTER_APP_KEY_SECRET)
			.setOAuthAccessToken(TWITTER_ACCESS_TOKEN)
			.setOAuthAccessTokenSecret(TWITTER_ACCESS_TOKEN_SECRET);	

			TwitterFactory tf = new TwitterFactory(config.build());
			twitter = tf.getInstance();

		}
	}

	public void addTweep(String tweep){
		newsTweeps.add(tweep);
	}


	@Override
	public void getRecentNews() {
		List<Status> statuses = null;

		try(FileWriter fw = new FileWriter("newsfile.csv", true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter outputFile = new PrintWriter(bw))		
		{
			for(String tweep: newsTweeps){
				try {
					Paging page = new Paging(17, 2000);
					System.out.println(page.getMaxId());

					statuses = twitter.getUserTimeline(tweep , page);
					getStatuses(statuses, outputFile);

				} catch (TwitterException e) {
					// TODO Auto-generated catch block;
				}
			}
		} catch (IOException e) {
			System.out.println("Error reading file");
		}


	}

	public void getStatuses(List<Status> statuses, PrintWriter file){
		TwitterFilter filter = new TwitterFilter();
		for (Status status : statuses) {

			if (filter.isRelavent(status.getText(), "syria")){
				String relevantStatusUsername = status.getUser().getName();
				String relevantStatus = status.getText();
				Date date = status.getCreatedAt();
				System.out.println(relevantStatusUsername + ":" + relevantStatus );
				System.out.println("Date " + date);
				String[] texts = relevantStatus.split("http://");
				if(texts.length == 2){
					file.println(relevantStatusUsername + "," + texts[0] + "," + texts[1] + "," + status.getCreatedAt());
				} else {
					file.println(relevantStatusUsername + "," + texts[0] + ", ," + status.getCreatedAt());	
				}
			}
		}

	}
}