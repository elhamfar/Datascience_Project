
public class TwitterFilter implements Filter {

	@Override
	public Boolean isRelavent(String phrase, String key) {
		if (phrase.toLowerCase().contains(key))
			return true;
		else
			return false;
	}

	@Override
	public String saperate(String phrase, String key) {
		// TODO Auto-generated method stub
		return null;
	}	

}
