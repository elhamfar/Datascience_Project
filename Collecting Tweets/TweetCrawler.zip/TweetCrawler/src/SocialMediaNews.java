import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;

public class SocialMediaNews {
	private static PrintWriter outputFile;

	public static void main(String[] args) throws Exception {
		getNewsFromTwitter();
		TwitterFilter filter = new TwitterFilter();
		String s = "";
		System.out.println(filter.isRelavent(s, "حادث"));
		System.out.println(filter.isRelavent(s, "accident"));
		if (filter.isRelavent(s, "accident") || (isArabic(s) && filter.isRelavent(s, "حريق"))) {
			System.out.println("YAY");
		}
	}

	public static void getNewsFromTwitter() throws Exception {
		// Twitter twitter = new Twitter();
		// String[] newsTweeps = {"FoxNews"};
		// for(String tweep: newsTweeps){
		// twitter.addTweep(tweep);
		// }
		// twitter.getRecentNews();

		// ALJAZEERA
		// "CNN", "FoxNews", "MSNBC", "BBC" ,"Reuters", "AlArabiya_Eng",
		// "BBCBreaking", "ReutersWorld",

		String[] tweeps = { "CivilDefenseLB" };
		try (FileWriter fw = new FileWriter("newsfile.csv", true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter outputFile = new PrintWriter(bw)) {
			for (String tweep : tweeps) {
				TwitterCriteria criteria = TwitterCriteria.create().setUsername(tweep).setSince("2009-01-01");
				TwitterFilter filter = new TwitterFilter();
				List<Tweet> t = TweetManager.getTweets(criteria);
				int size = t.size();
				for (int i = 0; i < size; i++) {
					String tweet = t.get(i).getText();
					System.out.println(tweet + t.get(i).getDate());

					if (filter.isRelavent(tweet, "accident") || (isArabic(tweet) && filter.isRelavent(tweet, "حادث")) || (isArabic(tweet) && filter.isRelavent(tweet, "حريق"))) {
						tweet = tweet.replaceAll(",", "");
						String[] texts = tweet.split("http://");

						if (texts.length == 2)
							outputFile.println(tweep + "," + texts[0] + "," + texts[1] + "," + t.get(i).getDate());
						else
							outputFile.println(tweep + "," + texts[0] + ", NA ," + t.get(i).getDate());
					}
				}
			}
		}

	}

	public static boolean isArabic(String s) {
		for (int i = 0; i < s.length();) {
			int c = s.codePointAt(i);
			if (c >= 0x0600 && c <= 0x06E0)
				return true;
			i += Character.charCount(c);
		}
		return false;
	}

}
