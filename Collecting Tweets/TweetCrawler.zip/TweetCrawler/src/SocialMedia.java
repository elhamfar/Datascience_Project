
public interface SocialMedia {
	
	public default void getRecentNews(){}

}
